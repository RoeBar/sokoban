
export const devLevels = {
    'level_1': `
    {
  "boardSize": 10,
  "cellSize": 355.6,
  "initialMana": 24,
  "playerInitialX": 4,
  "playerInitialY": 5,
  "objectsList": [
    {
      "type": "wooden_box",
      "x": 0,
      "y": 0,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wooden_box",
      "x": 1,
      "y": 0,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "metal_box",
      "x": 2,
      "y": 0,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "buttonAndDoor",
      "x": 3,
      "y": 2,
      "doorX": 5,
      "doorY": 2
    }
  ]
}
`,
    'level_2': `
{
  "boardSize": 10,
  "cellSize": 355.6,
  "initialMana": 30,
  "playerInitialX": 5,
  "playerInitialY": 5,
  "objectsList": [
    {
      "type": "wooden_box",
      "x": 4,
      "y": 5,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "buttonAndDoor",
      "x": 2,
      "y": 2,
      "doorX": 6,
      "doorY": 2
    },
    {
      "type": "wooden_box",
      "x": 6,
      "y": 4,
      "doorX": 0,
      "doorY": 0
    }
  ]
}
`,
    'level_3': `
    
`,
    'level_4': `
    
`,
    'level_5': `
    
`,
    'level_6': `
    
`,
    'level_7': `
    
`,
    'level_8': `
    {
  "boardSize": 10,
  "cellSize": 355.6,
  "initialMana": "24",
  "playerInitialX": 4,
  "playerInitialY": 5,
  "objectsList": [
    {
      "type": "wall",
      "x": 8,
      "y": 0,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 7,
      "y": 0,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 6,
      "y": 0,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 5,
      "y": 0,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 1,
      "y": 1,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 1,
      "y": 0,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 8,
      "y": 2,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 7,
      "y": 2,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 6,
      "y": 2,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 5,
      "y": 2,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 4,
      "y": 2,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 3,
      "y": 2,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 2,
      "y": 4,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 3,
      "y": 4,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 5,
      "y": 4,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 7,
      "y": 4,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 8,
      "y": 4,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 8,
      "y": 8,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 7,
      "y": 8,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 6,
      "y": 7,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 3,
      "y": 8,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 3,
      "y": 7,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 3,
      "y": 8,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 4,
      "y": 8,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 4,
      "y": 7,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 3,
      "y": 6,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wall",
      "x": 1,
      "y": 9,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "metal_box",
      "x": 6,
      "y": 4,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "metal_box",
      "x": 8,
      "y": 1,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "metal_box",
      "x": 3,
      "y": 3,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wooden_box",
      "x": 6,
      "y": 6,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wooden_box",
      "x": 7,
      "y": 7,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wooden_box",
      "x": 8,
      "y": 6,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wooden_box",
      "x": 9,
      "y": 6,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "wooden_box",
      "x": 2,
      "y": 8,
      "doorX": 0,
      "doorY": 0
    },
    {
      "type": "buttonAndDoor",
      "x": 0,
      "y": 1,
      "doorX": 9,
      "doorY": 9
    },
    {
      "type": "buttonAndDoor",
      "x": 0,
      "y": 2,
      "doorX": 0,
      "doorY": 4
    },
    {
      "type": "buttonAndDoor",
      "x": 0,
      "y": 3,
      "doorX": 0,
      "doorY": 9
    },
    {
      "type": "buttonAndDoor",
      "x": 3,
      "y": 5,
      "doorX": 0,
      "doorY": 5
    },
    {
      "type": "buttonAndDoor",
      "x": 3,
      "y": 9,
      "doorX": 0,
      "doorY": 6
    },
    {
      "type": "buttonAndDoor",
      "x": 1,
      "y": 2,
      "doorX": 2,
      "doorY": 9
    },
    {
      "type": "buttonAndDoor",
      "x": 4,
      "y": 9,
      "doorX": 2,
      "doorY": 0
    },
    {
      "type": "buttonAndDoor",
      "x": 8,
      "y": 3,
      "doorX": 5,
      "doorY": 9
    },
    {
      "type": "buttonAndDoor",
      "x": 9,
      "y": 8,
      "doorX": 6,
      "doorY": 1
    },
    {
      "type": "buttonAndDoor",
      "x": 5,
      "y": 1,
      "doorX": 9,
      "doorY": 0
    },
    {
      "type": "buttonAndDoor",
      "x": 8,
      "y": 5,
      "doorX": 7,
      "doorY": 6
    },
    {
      "type": "buttonAndDoor",
      "x": 9,
      "y": 5,
      "doorX": 9,
      "doorY": 3
    },
    {
      "type": "buttonAndDoor",
      "x": 0,
      "y": 8,
      "doorX": 5,
      "doorY": 5
    },
    {
      "type": "wooden_box",
      "x": 1,
      "y": 6,
      "doorX": 0,
      "doorY": 0
    }
  ]
}
`,
}